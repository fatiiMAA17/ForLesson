def print_to_n(n):
    for i in range(1, n + 1):
        print(i, end = " ")
