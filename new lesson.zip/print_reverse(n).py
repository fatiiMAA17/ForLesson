def print_reverse(n):
    for i  in range(n, 0, -1):
        print(i, end" ")